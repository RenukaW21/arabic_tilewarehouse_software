'use strict';
const { query } = require('../../config/db');
const { parsePagination } = require('../../utils/pagination');
const { v4: uuidv4 } = require('uuid');

const findAll = async (tenantId, queryParams) => {
  const { page, limit, offset, sortBy, sortOrder, search } = parsePagination(queryParams, ['receipt_date', 'created_at', 'grn_number']);
  const conditions = ['g.tenant_id = ?'];
  const params = [tenantId];

  if (queryParams.status)            { conditions.push('g.status = ?');            params.push(queryParams.status); }
  if (queryParams.vendorId)          { conditions.push('g.vendor_id = ?');         params.push(queryParams.vendorId); }
  if (queryParams.warehouseId)       { conditions.push('g.warehouse_id = ?');      params.push(queryParams.warehouseId); }
  if (queryParams.purchase_order_id) { conditions.push('g.purchase_order_id = ?'); params.push(queryParams.purchase_order_id); }
  if (search) { conditions.push('(g.grn_number LIKE ? OR v.name LIKE ?)'); params.push(`%${search}%`, `%${search}%`); }

  const where = conditions.join(' AND ');
  const [rows, count] = await Promise.all([
    query(
      `SELECT g.*, v.name AS vendor_name, w.name AS warehouse_name, po.po_number AS po_number
       FROM grn g
       JOIN vendors v ON g.vendor_id = v.id
       JOIN warehouses w ON g.warehouse_id = w.id
       LEFT JOIN purchase_orders po ON g.purchase_order_id = po.id AND po.tenant_id = g.tenant_id
       WHERE ${where} ORDER BY g.${sortBy} ${sortOrder} LIMIT ${limit} OFFSET ${offset}`,
      params
    ),
    query(
      `SELECT COUNT(*) AS total FROM grn g
       JOIN vendors v ON g.vendor_id = v.id
       LEFT JOIN purchase_orders po ON g.purchase_order_id = po.id AND po.tenant_id = g.tenant_id
       WHERE ${where}`,
      params
    ),
  ]);
  return { rows, total: count[0].total };
};

// FIX — findById now:
//   1. Returns po_number from linked purchase_order (for the PO banner in GRN detail page)
//   2. Returns ordered_boxes per item by joining purchase_order_items (for "Ordered" column)
const findById = async (id, tenantId) => {
  const grns = await query(
    `SELECT g.*, v.name AS vendor_name, w.name AS warehouse_name,
            po.po_number AS po_number
     FROM grn g
     JOIN vendors v ON g.vendor_id = v.id
     JOIN warehouses w ON g.warehouse_id = w.id
     LEFT JOIN purchase_orders po ON g.purchase_order_id = po.id AND po.tenant_id = g.tenant_id
     WHERE g.id = ? AND g.tenant_id = ?`,
    [id, tenantId]
  );
  if (!grns.length) return null;

  const grn = grns[0];

  // For items: if this GRN is linked to a PO, also pull ordered_boxes from purchase_order_items
  // matching on product_id AND shade_id (using NULL-safe comparison <=>)
  const items = await query(
    `SELECT gi.*,
            p.name AS product_name, p.code AS product_code, p.sqft_per_box,
            s.shade_code, s.shade_name,
            b.batch_number,
            r.name AS rack_name,
            poi.ordered_boxes AS ordered_boxes
     FROM grn_items gi
     JOIN products p ON gi.product_id = p.id
     LEFT JOIN shades s ON gi.shade_id = s.id
     LEFT JOIN batches b ON gi.batch_id = b.id
     LEFT JOIN racks r ON gi.rack_id = r.id
     LEFT JOIN purchase_order_items poi
            ON poi.purchase_order_id = ? 
           AND poi.product_id = gi.product_id
           AND (poi.shade_id <=> gi.shade_id)
           AND poi.tenant_id = gi.tenant_id
     WHERE gi.grn_id = ? AND gi.tenant_id = ?`,
    [grn.purchase_order_id || null, id, tenantId]
  );

  return { ...grn, items };
};

const createGRN = async (trx, { tenantId, grnNumber, purchaseOrderId, vendorId, warehouseId, receiptDate, invoiceNumber, invoiceDate, vehicleNumber, notes, createdBy }) => {
  const id = uuidv4();
  await trx.query(
    `INSERT INTO grn (id, tenant_id, grn_number, purchase_order_id, vendor_id, warehouse_id,
      receipt_date, invoice_number, invoice_date, vehicle_number, grand_total, status, notes, created_by, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 'draft', ?, ?, NOW())`,
    [id, tenantId, grnNumber, purchaseOrderId || null, vendorId, warehouseId,
     receiptDate || new Date(), invoiceNumber || null, invoiceDate || null,
     vehicleNumber || null, notes || null, createdBy]
  );
  return id;
};

const createGRNItem = async (trx, { tenantId, grnId, product_id, shade_id, batch_id, rack_id, received_boxes, received_pieces, damaged_boxes, unit_price, quality_status, quality_notes }) => {
  const id = uuidv4();
  await trx.query(
    `INSERT INTO grn_items (id, tenant_id, grn_id, product_id, shade_id, batch_id, rack_id,
      received_boxes, received_pieces, damaged_boxes, unit_price, quality_status, quality_notes, barcode_printed)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, FALSE)`,
    [id, tenantId, grnId, product_id, shade_id || null, batch_id || null, rack_id || null,
     received_boxes, received_pieces || 0, damaged_boxes || 0, unit_price || 0,
     quality_status || 'pending', quality_notes || null]
  );
  return id;
};

const updateStatus = async (trx, id, tenantId, status) => {
  await trx.query(`UPDATE grn SET status = ? WHERE id = ? AND tenant_id = ?`, [status, id, tenantId]);
};

const updateGRN = async (id, tenantId, data) => {
  const allowed = ['receipt_date', 'invoice_number', 'invoice_date', 'vehicle_number', 'notes', 'vendor_id', 'warehouse_id'];
  const updates = [];
  const params = [];
  for (const key of allowed) {
    if (data[key] !== undefined) {
      updates.push(`${key} = ?`);
      params.push(data[key]);
    }
  }
  if (updates.length === 0) return;
  params.push(id, tenantId);
  await query(
    `UPDATE grn SET ${updates.join(', ')} WHERE id = ? AND tenant_id = ?`,
    params
  );
};

// FIX — recalculate and persist grand_total on grn whenever items change
// line_total per item = received_boxes * unit_price (GRN doesn't have discount/tax per item)
const recalcGrandTotal = async (grnId, tenantId, trxOrQuery) => {
  const run = trxOrQuery ? trxOrQuery.query.bind(trxOrQuery) : query;
  await run(
    `UPDATE grn SET grand_total = (
       SELECT COALESCE(SUM(received_boxes * unit_price), 0)
       FROM grn_items
       WHERE grn_id = ? AND tenant_id = ?
     ) WHERE id = ? AND tenant_id = ?`,
    [grnId, tenantId, grnId, tenantId]
  );
};

const addGRNItem = async (tenantId, grnId, item) => {
  const id = uuidv4();
  const receivedBoxes  = parseFloat(item.received_boxes)  || 0;
  const receivedPieces = parseFloat(item.received_pieces) || 0;
  const damagedBoxes   = parseFloat(item.damaged_boxes)   || 0;
  const unitPrice      = parseFloat(item.unit_price)      || 0;
  await query(
    `INSERT INTO grn_items (id, tenant_id, grn_id, product_id, shade_id, batch_id, rack_id,
      received_boxes, received_pieces, damaged_boxes, unit_price, quality_status, quality_notes, barcode_printed)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, FALSE)`,
    [id, tenantId, grnId, item.product_id, item.shade_id || null, item.batch_id || null, item.rack_id || null,
     receivedBoxes, receivedPieces, damagedBoxes, unitPrice,
     item.quality_status || 'pending', item.quality_notes || null]
  );
  // FIX — update grand_total after adding an item
  await recalcGrandTotal(grnId, tenantId, null);
  return id;
};

const deleteGRN = async (id, tenantId) => {
  await query('DELETE FROM grn_items WHERE grn_id = ? AND tenant_id = ?', [id, tenantId]);
  const deleteResult = await query('DELETE FROM grn WHERE id = ? AND tenant_id = ? AND status = ?', [id, tenantId, 'draft']);
  return deleteResult && deleteResult.affectedRows > 0;
};

// FIX — shade_id now matched when rolling up received_boxes to PO items
const updatePOReceivedBoxes = async (trx, purchaseOrderId, tenantId) => {
  if (!purchaseOrderId) return;

  await trx.query(
    `UPDATE purchase_order_items poi
     SET poi.received_boxes = (
       SELECT COALESCE(SUM(gi.received_boxes), 0)
       FROM grn_items gi JOIN grn g ON gi.grn_id = g.id
       WHERE g.purchase_order_id = ?
         AND gi.product_id = poi.product_id
         AND (gi.shade_id <=> poi.shade_id)
         AND g.tenant_id = ?
         AND g.status = 'posted'
     )
     WHERE poi.purchase_order_id = ? AND poi.tenant_id = ?`,
    [purchaseOrderId, tenantId, purchaseOrderId, tenantId]
  );

  await trx.query(
    `UPDATE purchase_orders po
     SET received_date = COALESCE(po.received_date,
       (SELECT MIN(g.receipt_date) FROM grn g WHERE g.purchase_order_id = po.id AND g.tenant_id = ? AND g.status = 'posted'))
     WHERE po.id = ? AND po.tenant_id = ?`,
    [tenantId, purchaseOrderId, tenantId]
  );

  await trx.query(
    `UPDATE purchase_orders SET
       status = CASE
         WHEN (SELECT SUM(ordered_boxes - received_boxes) FROM purchase_order_items WHERE purchase_order_id = ? AND tenant_id = ?) <= 0 THEN 'received'
         WHEN (SELECT SUM(received_boxes) FROM purchase_order_items WHERE purchase_order_id = ? AND tenant_id = ?) > 0 THEN 'partial'
         ELSE status
       END,
       updated_at = NOW()
     WHERE id = ? AND tenant_id = ?`,
    [purchaseOrderId, tenantId, purchaseOrderId, tenantId, purchaseOrderId, tenantId]
  );
};

module.exports = {
  findAll,
  findById,
  createGRN,
  createGRNItem,
  updateStatus,
  updateGRN,
  addGRNItem,
  deleteGRN,
  updatePOReceivedBoxes,
  recalcGrandTotal,
};
